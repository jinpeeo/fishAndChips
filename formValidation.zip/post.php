<?

$vars = $_POST;
print_r($vars);

?>